<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GCommande/Nouveau mot de passe</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
        <form action="#">
            <span id="alert">Veuillez compléter ces informations</span>
            <h1>Nouveau password</h1>
            <label>Nouveau mot de passe</label>
            <input type="password" name="">
            <label>Confirmation</label>
            <input type="password" name="" >
            <input type="submit" value="Modifier">
            <a href="#">Retour connexion</a>
        </form>
</body>
</html>  